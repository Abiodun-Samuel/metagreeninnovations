<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, ['pageheader' => ''.e($innertitle).'','subpageheader' => '','pagedescription' => 'Take a look at our recently completed projects executed with a touch of excellence and professionalism.']); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="projects my-5">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 d-flex align-items-stretch my-4" data-aos="fade-up">
                        <div class="card">
                            <div class="card-pix">
                                <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img loading="lazy"
                                                src="<?php echo e(url('storage/images/projects/' . $project->image_main)); ?>"
                                                class="img-fluid bg-secondary" alt="our project" title="Our Projects"
                                                height="350" width="500">
                                        </div>
                                        <?php $__currentLoopData = json_decode($project->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item">
                                                <img loading="lazy" src="<?php echo e(url('storage/images/projects/' . $img)); ?>"
                                                    class="img-fluid bg-secondary" alt="our project" title="Our Projects"
                                                    height="350" width="500">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>
                            </div>

                            <div class="card-body">
                                <h3 class="card-title"><?php echo e($project->title); ?></h3>
                                <p class="card-text"> <?php echo e($project->sub_title); ?> </p>
                                <a href="<?php echo e(route('admin.show', $project->slug)); ?>"> Read More</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Cta::class, ['cta' => 'You can also enjoy this too. Take the first step towards safe and steady electricity.','page' => 'Contact Us']); ?>
<?php $component->withName('cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69)): ?>
<?php $component = $__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69; ?>
<?php unset($__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\Projects.blade.php ENDPATH**/ ?>