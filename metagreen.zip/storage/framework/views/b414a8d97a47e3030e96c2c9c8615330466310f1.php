<?php $__env->startComponent('mail::message'); ?>

New Message From <?php echo e($data['name']); ?>


Name: <?php echo e($data['name']); ?> 

Email: <?php echo e($data['email']); ?>


Phone: <?php echo e($data['phone']); ?>


Subject: <?php echo e($data['subject']); ?>


Message: <?php echo e($data['message']); ?>



<?php $__env->startComponent('mail::button', ['url' => 'mailto:' . $data['email']]); ?>
Reply
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => 'tel:' . $data['phone']]); ?>
Call
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\emails\email.blade.php ENDPATH**/ ?>