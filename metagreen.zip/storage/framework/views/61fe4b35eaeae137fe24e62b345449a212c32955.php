<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name=”robots” content="none">
    <meta http-equiv="X-UA-Compatible" content="IE=7">
    <meta name="description"
        content="Metagreen Innovations is a reputable leading solar company in Nigeria, providing all range of customized, integrated solar solutions and products to customers in all sectors. We provide quality products and services with sound technical knowledge, skills and commitment to excellence. We started operations in the year 2017 and had since established our brand as a force to reckon with in the energy sector. We are a well-known source in renewable energy market starting from conception, feasibility, load auditing, designing and execution.">

    <title> <?php echo e($metatitle ?? 'Metagreen Innovations'); ?> </title>

    
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('/images/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('/images/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('/images/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(url('/images/site.webmanifest')); ?>">

    
    <link
        href="https://fonts.googleapis.com/css2?family=Merriweather:wght@300;400;700;900&family=Montserrat:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">

    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/css/app.css?ver=1.231')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>

    
    <link rel="stylesheet" href="<?php echo e(url('style.css?ver=1.2')); ?>" />
    

</head>

<body>

    <?php echo $__env->yieldContent('auth'); ?>

    <?php echo $__env->make('cookie-consent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
        crossorigin="anonymous"></script>
    <script src="<?php echo e(url('js/app.js')); ?>"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js">
    </script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script src="<?php echo e(url('script.js?ver=1.0')); ?>"></script>
    

</body>

</html>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\layouts\nav.blade.php ENDPATH**/ ?>