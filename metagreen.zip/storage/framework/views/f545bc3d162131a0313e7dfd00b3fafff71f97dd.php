<?php $__env->startSection('auth'); ?>
    <section class="auth">
        <div class="container">
            <div class="row justify-content-center mt-4">
                <div class="col-lg-5 mt-5">
                    <div class="auth-card mt-5">

                        <div class="mb-4">
                            <?php echo e(__('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.')); ?>

                        </div>

                        <?php if(session('status') == 'verification-link-sent'): ?>
                            <div class="alert alert-danger">
                                <p class="p-1">
                                    <?php echo e(__('A new verification link has been sent to the email address you provided during registration.')); ?>

                                </p>
                            </div>
                        <?php endif; ?>

                        <div class="mt-4 ">
                            <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                                <?php echo csrf_field(); ?>

                                <div>
                                    <button class="mybtn">
                                        <?php echo e(__('Resend Verification Email')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.auth-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>