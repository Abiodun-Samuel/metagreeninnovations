<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, ['pageheader' => ''.e($innertitle).'','subpageheader' => '','pagedescription' => 'Take a look at our recently completed projects executed with a touch of excellence and professionalism.']); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="projects my-5">
        <div class="container">
            <div class="row">
                <?php if (isset($component)) { $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Project::class, ['aos' => '0','folder' => 'Oral Estate Project','description' => '5KVA Complete Solar System at Oral Estate.','image' => 'image2']); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558)): ?>
<?php $component = $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558; ?>
<?php unset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Project::class, ['aos' => '50','folder' => 'Buena Vista Estate Project 1','description' => '20KVA Complete Solar System at Buena Vista Estate (Project 1).','image' => 'image3']); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558)): ?>
<?php $component = $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558; ?>
<?php unset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Project::class, ['aos' => '100','folder' => 'Lekki County Homes Project','description' => '5KVA Complete System at Lekki County Homes.','image' => 'image3']); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558)): ?>
<?php $component = $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558; ?>
<?php unset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Project::class, ['aos' => '150','folder' => 'Buena Vista Estate Project 2','description' => '20KVA Complete Solar System at Buena Vista Estate (Project 2).','image' => 'image1']); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558)): ?>
<?php $component = $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558; ?>
<?php unset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Project::class, ['aos' => '200','folder' => 'Olusegun Obasanjo Hilltop Project','description' => '5KVA Inverter System at Olusegun Obasanjo Hilltop.','image' => 'image2']); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558)): ?>
<?php $component = $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558; ?>
<?php unset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Project::class, ['aos' => '250','folder' => 'Olomore Housing Estate Project','description' => '5 KVA Complete Solar System at Olomore Housing Estate.','image' => 'image1']); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558)): ?>
<?php $component = $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558; ?>
<?php unset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Project::class, ['aos' => '300','folder' => 'Patheon Smart Terrace Project','description' => '15KVA Complete Solar System at Patheon Smart Terrace Estate.','image' => 'image1']); ?>
<?php $component->withName('project'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558)): ?>
<?php $component = $__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558; ?>
<?php unset($__componentOriginald155c4e3932e3ac8f9e9a376819b84fa5f15f558); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>

        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Cta::class, ['cta' => 'You can also enjoy this too. Take the first step towards safe and steady electricity.','page' => 'Contact Us']); ?>
<?php $component->withName('cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69)): ?>
<?php $component = $__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69; ?>
<?php unset($__componentOriginald677f82e54e42f61b391c66e66511c5bb1c2da69); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\metagreen\resources\views/Projects.blade.php ENDPATH**/ ?>