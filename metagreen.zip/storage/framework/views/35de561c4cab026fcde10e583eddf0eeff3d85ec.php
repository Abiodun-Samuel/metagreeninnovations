<div class="cta py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-8 col-sm-6 my-3">
                <h3> <?php echo e($cta); ?> </h3>
            </div>
            <div class=" col-lg-3 col-md-4 col-sm-6 my-3">
                <button><a class="" href="<?php echo e(url('/' . $page)); ?>"> <?php echo e($page); ?></a></button>
            </div>
        </div>

    </div>
</div>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\components\cta.blade.php ENDPATH**/ ?>