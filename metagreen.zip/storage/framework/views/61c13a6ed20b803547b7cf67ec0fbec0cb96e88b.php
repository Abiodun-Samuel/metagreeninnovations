<div class="cta">
    <div class="container text-center p-5">
        <h3>Do you have any question about our services or you want to make enquiry? <a href="<?php echo e(url('/contact')); ?>">Contact Us Now</a>
        </h3>
    </div>
</div>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\metagreen\resources\views/layouts/cta-layout.blade.php ENDPATH**/ ?>