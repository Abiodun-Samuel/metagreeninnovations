

<?php $__env->startSection('content'); ?>

    <div class="innerheader py-5">
        <div class="container py-5">
            <h3> <a href="<?php echo e(route('home')); ?>">Home</a> | <a href="<?php echo e(route('projects')); ?>"> Project </a> |
                <span><?php echo e($project->sub_title); ?></span>
            </h3>
        </div>
    </div>

    <div class="projectdetails my-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 my-4">
                    <div class="projectdetails">

                        <h4>Project Details</h4>

                        <hr>

                        <p> <b>Title:</b> <span> <?php echo e($project->title); ?></span> </p>
                        <p> <b>Location: </b> <span> <?php echo e($project->location); ?> </span> </p>
                        <p> <b>Date: </b> <span> <?php echo e($project->date); ?> </span> </p>
                        <p> <b>Components: </b>
                            <span>
                                <ul class="ml-5">
                                    <?php for($i = 0; $i < count($components); $i++): ?>
                                        <li><?php echo e($components[$i]); ?></li>
                                    <?php endfor; ?>
                                </ul>
                            </span>
                        </p>
                    </div>
                </div>

                <div class="col-lg-7 my-4">
                    <h4>Project Gallery</h4>
                    <div class="project-gallery">

                        <?php for($i = 0; $i < count($images); $i++): ?>
                            <a class="venobox" data-gall="gallery01"
                                href="<?php echo e(url('storage/images/projects/' . $images[$i])); ?>">
                                <img loading="lazy" width="500" height="350" class="img-fluid bg-secondary" src="<?php echo e(url('storage/images/projects/' . $images[$i])); ?>">
                            </a>
                        <?php endfor; ?>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/venobox/1.9.3/venobox.min.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/venobox/1.9.3/venobox.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views/projects/show.blade.php ENDPATH**/ ?>