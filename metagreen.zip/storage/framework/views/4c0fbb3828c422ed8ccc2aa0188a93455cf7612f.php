<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, ['pageheader' => 'Projects','subpageheader' => ' | '.e($innertitle).'','pagedescription' => '']); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="projectdetails my-5">

        <div class="container">
            <div class="row">
                <div class="col-lg-5 my-4">
                    <div class="projectdetails">

                        <h4>Project Details</h4>

                        <hr>

                        <p> <b>Title:</b> <span>Design, Supply and Installation.</span> </p>
                        <p> <b>Location: </b> <span>Lekki County Homes, Lagos State Nigeria. </span> </p>
                        <p> <b>Date: </b> <span> January 2021.</span> </p>
                        <p> <b>Components: </b>
                            <span>
                                <ul class="ml-5">
                                    <li>5KVA Inverter.</li>
                                    <li>4 Units of 200AH Tubular Batteries.</li>
                                    <li>8 Modules of 280Watts Solar Panels.</li>
                                    <li>1 Unit of 60Amps MPPT Charge Controller.</li>
                                    <li>Other Complimentary Assessories.</li>
                                </ul>
                            </span>
                        </p>
                    </div>

                </div>

                <div class="col-lg-7 my-4">
                    <h4>Project Gallery</h4>
                    <div class="project-gallery">
                        <a class="venobox" data-gall="gallery01"
                            href="<?php echo e(url('/images/projects/Lekki County Homes Project/image1.jpg')); ?>">
                            <img loading="lazy" width="500" height="350" class="img-fluid bg-secondary"
                                src="<?php echo e(url('/images/projects/Lekki County Homes Project/image1.jpg')); ?>">
                        </a>
                        <a class="venobox" data-gall="gallery01"
                            href="<?php echo e(url('/images/projects/Lekki County Homes Project/image2.jpg')); ?>">
                            <img loading="lazy" width="500" height="350" class="img-fluid bg-secondary"
                                src="<?php echo e(url('/images/projects/Lekki County Homes Project/image2.jpg')); ?>">
                        </a>
                        <a class="venobox" data-gall="gallery01"
                            href="<?php echo e(url('/images/projects/Lekki County Homes Project/image3.jpg')); ?>">
                            <img loading="lazy" width="500" height="350" class="img-fluid bg-secondary"
                                src="<?php echo e(url('/images/projects/Lekki County Homes Project/image3.jpg')); ?>">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\metagreen\resources\views/projects/Lekki County Homes Project.blade.php ENDPATH**/ ?>