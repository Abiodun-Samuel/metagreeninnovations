<tr>
    <td class="header">
        <a href="https://metagreeninnovations.com" style=" display: block;">
            <img src="https://metagreeninnovations.com/images/logo.jpg" class="logo" alt="Metagreen Innovations Logo">
        </a>
    </td>
</tr>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>