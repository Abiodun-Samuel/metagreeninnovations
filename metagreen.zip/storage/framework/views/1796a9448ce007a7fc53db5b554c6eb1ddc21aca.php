<?php $__env->startSection('auth'); ?>
    <section class="auth">
        <div class="container">
            <div class="row d-flex justify-content-center mt-4">
                <div class="col-lg-5 mt-3">
                    <div class="auth-card">
                        <img class="img-fluid mx-auto mb-5" src="<?php echo e(url('images/logo.jpg')); ?>"
                            alt="metagreen innovations logo">

                        <h3>Login</h3>

                        <form class="mt-4 mb-3" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($error); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e(session('status')); ?></p>
                                </div>
                            <?php endif; ?>

                            

                            <!-- Email Address -->
                            <div class="form-group">
                                <label for="email"><?php echo e(__('E-Mail*')); ?></label>
                                <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>"
                                    autocomplete="email">
                            </div>

                            <!-- Password -->
                            <div class="form-group">
                                <label for="password"> <?php echo e(__('Password*')); ?> </label>
                                <input id="password" class="block mt-1 w-full" type="password" name="password"
                                    autocomplete="new-password" />
                            </div>

                            <!-- Remember Me -->
                            <div class="form-group">
                                <div class="form-check form-check-inline">
                                    <label class="form-check-label" for="remember_me"><?php echo e(__('Remember me')); ?></label>
                                    <input class="form-check-input mx-2" type="checkbox" id="remember_me" name="remember">
                                </div>
                            </div>

                            <div class="form-group">
                                <?php if(Route::has('password.request')): ?>
                                    <p>
                                        <a class="text-danger" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot your password?')); ?>

                                        </a>
                                    </p>
                                <?php endif; ?>
                                <p> Guest? <a href="<?php echo e(route('register')); ?>">Register</a> </p>
                            </div>

                            <button class="mybtn" onclick="this.classList.toggle('button--loading')">
                                <?php echo e(__('Log in')); ?>

                            </button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.auth-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        // loader for button
        const btn = document.querySelector(".button");
        btn.classList.add("button--loading");
        btn.classList.remove("button--loading");
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\auth\login.blade.php ENDPATH**/ ?>