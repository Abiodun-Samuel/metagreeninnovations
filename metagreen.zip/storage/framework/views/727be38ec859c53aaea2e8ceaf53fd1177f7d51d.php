<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title> <?php echo e($metatitle); ?> </title>

    
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('/images/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('/images/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('/images/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(url('/images/site.webmanifest')); ?>">

    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@300;400;500;700&family=Open+Sans:ital,wght@0,400;0,600;0,700;1,600&family=Zen+Dots&display=swap"
        rel="stylesheet">

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/venobox/1.9.3/venobox.min.css" />

    
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">

</head>

<body>

    
    <header>
        <nav class="navbar navbar-expand-lg fixed-top">

            <div class="container">

                
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img class="img-fluid" src="<?php echo e(url('images/logo.jpg')); ?>" alt="Metagreeen Innovations Logo">
                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                    aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <svg aria-hidden="true" focusable="false" width="2.2em" height="2.2em" viewBox="0 0 24 24">
                            <g>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M2 6a2 2 0 0 1 2-2h16a2 2 0 1 1 0 4H4a2 2 0 0 1-2-2zm0 6a2 2 0 0 1 2-2h16a2 2 0 1 1 0 4H4a2 2 0 0 1-2-2zm0 6a2 2 0 0 1 2-2h16a2 2 0 1 1 0 4H4a2 2 0 0 1-2-2z"
                                    fill="#d58943" />
                            </g>
                        </svg>
                    </span>
                </button>

                
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav ml-auto">
                        <a class="nav-link active" href="<?php echo e(url('/')); ?>"> HOME </a>
                        <a class="nav-link" href="<?php echo e(url('/about')); ?>"> ABOUT </a>
                        <a class="nav-link" href="<?php echo e(url('/service')); ?>"> SERVICES </a>
                        <a class="nav-link" href="<?php echo e(url('/project')); ?>"> PROJECTS </a>
                        <a class="nav-link" href="<?php echo e(url('/contact')); ?>"> CONTACT </a>
                    </div>
                </div>
            </div>

        </nav>
    </header>
    

    <?php echo $__env->yieldContent('content'); ?>

    <footer id="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">

                    
                    <div class="col-lg-4 col-md-6 footer-info">
                        <h3> Metagreen Innovations </h3>

                        <img class="img-thumbnail my-2" src="<?php echo e(url('images/ceo.jpg')); ?>"
                            alt="ceo of metagreen innovations">

                        <p>
                            <strong> Olorunnibi Ezekiel Dunsin</strong> is an entrepreneur by passion. By training, he
                            is an Electrical & Electronics Engineer. Being the CEO of Metagreen Innovations, he has
                            executed many
                            medium and large scale inverter and solar system installations in Nigeria since 2017.
                        </p>

                    </div>

                    <div class="col-lg-4 col-md-6 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href=" <?php echo e(url('/about')); ?>">About Us</a></li>
                            <li><a href="<?php echo e(url('/service')); ?>">Services</a></li>
                            <li><a href="<?php echo e(url('/project')); ?>">Projects</a></li>
                            <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-4 col-md-6 footer-contact">
                        <h4>Contact Us</h4>
                        <p>
                            <strong>Address:</strong> 5, Taiwo Aroyeun St, Goshen Estate, <br> Abeokuta, Ogun State,
                            Nigeria.
                            <br>

                            <strong>Phone 1:</strong> +2348062175217<br>
                            <strong>Phone 2:</strong> +2349015016567<br>
                            <strong>Email:</strong> contact@metagreeninnovations.com<br>
                        </p>

                        <div class="social-links">
                            
                            <a
                                href="https://api.whatsapp.com/send?phone=2349015016567&text=Welcome%20to%20Metagreen%20Innovations,%20How%20can%20we%20be%20of%20assistance?">
                                <i>
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        width="2.8rem" height="2.8rem" preserveAspectRatio="xMidYMid meet"
                                        viewBox="0 0 24 24">
                                        <g class="icon-tabler" fill="none" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21" />
                                            <path
                                                d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1" />
                                        </g>
                                    </svg>
                                </i>
                            </a>

                            
                            <a href="https://m.facebook.com/metagreen.innovations">
                                <i>
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        aria-hidden="true" focusable="false" width="2.7rem" height="2.7rem"
                                        style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);"
                                        preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32">
                                        <path
                                            d="M25.566 2.433H6.433c-2.2 0-4 1.8-4 4v19.135c0 2.2 1.8 4 4 4h19.135c2.2 0 4-1.8 4-4V6.433c-.002-2.2-1.8-4-4.002-4zm-.257 14.483h-3.22v11.65h-4.818v-11.65h-2.41V12.9h2.41v-2.41c0-3.276 1.36-5.225 5.23-5.225h3.217V9.28h-2.012c-1.504 0-1.604.563-1.604 1.61l-.013 2.01h3.645l-.426 4.016z" />
                                    </svg>
                                </i>
                            </a>

                            
                            
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="container">
            <div class="copyright">
                &copy; Copyright <strong><span>Metagreen Innovations</span></strong>. All Rights Reserved
            </div>
            <div class="credits">
                Designed & Developed by <strong>
                    <a href="https://wa.link/aqutc1">Abiodun Digital Hub</a>
                </strong>
            </div>
        </div>
    </footer>

    
    <a href="" class="back-to-top">
        <i>
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true"
                focusable="false" width="4rem" height="4rem"
                style="-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); transform: rotate(360deg);"
                preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                <path d="M4 21h16V8H4m10 7v3h-4v-3H7l5-5l5 5M3 3h18v4H3" fill="#245140" />
            </svg>
        </i>
    </a>


    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/venobox/1.9.3/venobox.min.js"></script>
    
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    


    
    <script src="<?php echo e(url('js/script.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\metagreen\resources\views/layouts/app.blade.php ENDPATH**/ ?>