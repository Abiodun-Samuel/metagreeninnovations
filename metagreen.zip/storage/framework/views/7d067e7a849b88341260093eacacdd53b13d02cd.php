<footer class="auth-footer text-center py-3">
    <div class="container">
        <div class="copyright">
            Copyright &copy; <span id="year"></span> <strong><span>Metagreen Innovations</span></strong>. All Rights
            Reserved
        </div>
        <div class="credits">
            Designed & Developed by <strong>
                <a class="text-dark" href="https://wa.link/aqutc1"> <strong>Abiodun Digital Hub</strong> </a>
            </strong>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\layouts\auth-footer.blade.php ENDPATH**/ ?>