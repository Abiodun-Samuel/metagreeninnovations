<?php $__env->startSection('title', __('Error')); ?>
<?php $__env->startSection('code', '500'); ?>
    
<?php $__env->startSection('message', __('qwerty')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\errors\500.blade.php ENDPATH**/ ?>