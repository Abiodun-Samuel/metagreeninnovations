<div class="js-cookie-consent cookie-consent">

    <span class="cookie-consent__message">
        <?php echo trans('cookie-consent::texts.message'); ?>

    </span>

    <button class="js-cookie-consent-agree cookie-consent__agree">
        <?php echo e(trans('cookie-consent::texts.agree')); ?>

    </button>

</div>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\vendor\cookie-consent\dialogContents.blade.php ENDPATH**/ ?>