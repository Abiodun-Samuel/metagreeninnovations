<?php echo e($slot); ?>

<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>