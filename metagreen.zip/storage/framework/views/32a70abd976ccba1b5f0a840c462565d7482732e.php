<tr>
    <td>
        <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
                <td class="content-cell" align="center">
                    <p><small>&copy; 2021 Metagreen Innovations. All Rights Reserved</small></p>
                </td>
            </tr>
        </table>
    </td>
</tr>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>