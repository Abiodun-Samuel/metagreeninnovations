<div class="innerheader py-5">
    <div class="container py-5">
        <h3> <a href="<?php echo e(url('/')); ?>">Home</a> | <a href="<?php echo e(url($pageheader)); ?>"> <?php echo e($pageheader); ?></a>
            <span><?php echo e($subpageheader ?? ''); ?></span>
        </h3>

        <p><?php echo e($pagedescription ?? ''); ?></p>
    </div>
</div>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\metagreen\resources\views/components/header.blade.php ENDPATH**/ ?>