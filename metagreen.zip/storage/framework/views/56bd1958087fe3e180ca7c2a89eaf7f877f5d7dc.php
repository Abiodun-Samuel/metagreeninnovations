<?php $__env->startComponent('mail::message'); ?>

<p> Dear <?php echo e($data['name']); ?>,</p>


<p>Your message has been received and we will get back to you promptly.</p> 


<p>Go back to</p> 
<?php $__env->startComponent('mail::button', ['url' => 'https://metagreeninnovations.com']); ?>
Homepage
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?> 

<p>Check out our recently completed </p> 
<?php $__env->startComponent('mail::button', ['url' => 'https://metagreeninnovations.com/project']); ?>
Projects
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?> 



<p>Once again, Thanks for contacting us.
<?php echo e(config('app.name')); ?>

</p>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views\emails\notify.blade.php ENDPATH**/ ?>