<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name=”robots” content="none">
    <meta http-equiv="X-UA-Compatible" content="IE=7">
    <meta name="description"
        content="Metagreen Innovations is a reputable leading solar company in Nigeria, providing all range of customized, integrated solar solutions and products to customers in all sectors. We provide quality products and services with sound technical knowledge, skills and commitment to excellence. We started operations in the year 2017 and had since established our brand as a force to reckon with in the energy sector. We are a well-known source in renewable energy market starting from conception, feasibility, load auditing, designing and execution.">

    <title> <?php echo e($metatitle ?? 'Clients | Metagreen Innovations'); ?> </title>

    
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('/images/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('/images/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('/images/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(url('/images/site.webmanifest')); ?>">

    
    <link
        href="https://fonts.googleapis.com/css2?family=Merriweather:wght@300;400;700;900&family=Montserrat:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">

    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/css/app.css?ver=1.231')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>

    
    <link rel="stylesheet" href="<?php echo e(url('style.css?ver=1.2')); ?>" />
    

</head>

<body>

    <section id="clients">
        <div class="container">
            <a href="<?php echo e(route('home')); ?>"
                class="nav-link text-light bg-primary my-2 px-3 py-1 d-inline-block">Homepage</a>

            <div class="row d-flex justify-content-center">
                <div class="col-lg-6">
                    <div class="clients p-4">
                        <a href="<?php echo e(route('home')); ?>"><img loading="lazy" class="mx-auto mb-5 bg-white"
                                src="<?php echo e(url('images/logo.jpg')); ?>" alt="Metagreen Innovations"
                                title="Metagreen Innovations" height="50" width="181"></a>

                        <h3>Edit </h3>
                        <p class="p-0 m-0"><?php echo e($client->name); ?>'s Testimonials</p>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="my-0"><?php echo e($error); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(session('status')); ?></p>
                            </div>
                        <?php endif; ?>

                        <form class="mt-4" action="<?php echo e(route('clients.update', $client->id)); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <label for="name">Name*</label>
                            <input type="text" name="name" value="<?php echo e($client->name); ?>" id="name">

                            <label for="comment">Comments*</label>
                            <textarea name="comments" id="comments" rows="3"><?php echo e($client->comments); ?></textarea>

                            <label for="address">Address(State & City)*</label>
                            <input type="text" name="address" value="<?php echo e($client->address); ?>" id="address">

                            <label for="image">Upload your picture* </label> <br>
                            <input type="file" name="image" id="image"><br>
                            <span>(formats: jpeg|jpg|png, file-size: less than 2048mb)</span>

                            <button type="submit">Submit</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('cookie-consent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
        crossorigin="anonymous"></script>
    <script src="<?php echo e(url('js/app.js')); ?>"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js">
    </script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script src="<?php echo e(url('script.js?ver=1.0')); ?>"></script>
    

</body>

</html>
<?php /**PATH C:\Users\user\Desktop\Laravel-Projects\metagreen\resources\views/clients/edit.blade.php ENDPATH**/ ?>