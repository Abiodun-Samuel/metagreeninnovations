<div class="js-cookie-consent cookie-consent">

    <span class="cookie-consent__message">
        <?php echo trans('cookie-consent::texts.message'); ?>

    </span>

    <button class="js-cookie-consent-agree cookie-consent__agree">
        <?php echo e(trans('cookie-consent::texts.agree')); ?>

    </button>

</div>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\metagreen\vendor\spatie\laravel-cookie-consent\src\/../resources/views/dialogContents.blade.php ENDPATH**/ ?>