<div class="js-cookie-consent cookie-consent">

    <span class="cookie-consent__message">
        <?php echo trans('cookie-consent::texts.message'); ?>

    </span>

    <button class="js-cookie-consent-agree cookie-consent__agree">
        <?php echo e(trans('cookie-consent::texts.agree')); ?>

    </button>

</div>
<?php /**PATH C:\Users\abiod\Desktop\PHP-Projects\metagreen\resources\views/vendor/cookie-consent/dialogContents.blade.php ENDPATH**/ ?>