@extends('layouts.app')

@section('content')

    @include('layouts.projectpage-layout')

    @include('layouts.cta-layout')

@endsection
