@extends('errors::minimal')

@section('title', __('Error'))
@section('code', '500')
    {{-- @section('message', __('Server Error')) --}}
@section('message', __('qwerty'))
