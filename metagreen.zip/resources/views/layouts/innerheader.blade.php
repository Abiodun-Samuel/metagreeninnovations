<div class="innerheader py-5">
    <div class="container py-5">
        <h3 class=""> <a href="{{ url('/') }}">Home</a> | <a href="{{ url('/project') }}">Project</a> |
            {{ $innertitle ?? '' }}</h3>
    </div>
</div>
