<div class="cta">
    <div class="container text-center p-5">
        <h3>Do you have any question about our services or you want to make enquiry? <a href="{{ url('/contact') }}">Contact Us Now</a>
        </h3>
    </div>
</div>
