@component('mail::message')

{{$data['subject']}}

Hi, 

I'm {{$data['name']}}

{{$data['message']}}


@component('mail::button', ['url' => 'mailto:' . $data['email']])
Reply
@endcomponent

@component('mail::button', ['url' => 'tel:' . $data['phone']])
Call
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
