<?php

use App\Http\Controllers\FormController;
use App\Http\Controllers\PagesController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

// Webpages
Route::get('/', [PagesController::class, 'index']);
Route::get('/about', [PagesController::class, 'about']);
Route::get('/project', [PagesController::class, 'project']);
Route::get('/projects/{project_page}', [PagesController::class, 'projectpage'])->where('project_page', 'Oral Estate Project|Buena Vista Estate Project|County Homes Project|Hilltop Estate Project|Olomore Housing Estate Project');
Route::get('/service', [PagesController::class, 'service']);

// Contact and send mail
Route::get('/contact', [FormController::class, 'contact']);
Route::post('/contact/sendmail', [FormController::class, 'sendmail'])->name('sendmail');

// Fallback route
Route::fallback(function () {
    return view('errors.404');
});
